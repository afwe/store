﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharp程序设计实验.实验一;

namespace CSharp程序设计实验
{
    class Program
    {
        static void Main(string[] args)
        {
            new overFlow();
            new text_3();
        }
    }
}
