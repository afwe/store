﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp程序设计实验.实验一
{
    class B:A
    {
        public override void MyMethod(int n)
        {
            Console.WriteLine("{0} + 50 = {1}", n, n + 50);
        }
    }
}
