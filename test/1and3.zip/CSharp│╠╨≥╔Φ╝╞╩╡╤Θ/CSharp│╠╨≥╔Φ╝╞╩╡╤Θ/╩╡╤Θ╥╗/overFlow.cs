﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp程序设计实验.实验一
{
    class overFlow
    {

        public overFlow()
        {
            Console.WriteLine("求1!+2!+...+n!的和");
            Console.WriteLine("请输入n:");
            int n = Int32.Parse(Console.ReadLine());
            if (n < 0)
            {
                Console.WriteLine("输入非法");
            }
            int result = getFactorialSum(n);
            if (result>=0)Console.WriteLine("阶乘和:" + getFactorialSum(n));
            Console.ReadLine();
        }
        public int getFactorialSum(int n)
        {
            
            int result = 0;
            int factor = 1;
            try
            {
                for(int i = 1; i <=n; i++)
                {
                    checked
                    {
                        factor *= i;
                        result += factor;
                    }
                }
            }catch(OverflowException ofe)
            {
                Console.WriteLine(ofe.Message);
                result = -1;
            }
            return result;
        }
    }
}
