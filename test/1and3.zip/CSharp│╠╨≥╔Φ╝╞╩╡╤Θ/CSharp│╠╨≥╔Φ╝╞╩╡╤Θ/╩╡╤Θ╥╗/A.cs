﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp程序设计实验.实验一
{
    class A
    {
        public virtual void MyMethod(int n)
        {
            Console.WriteLine("{0} + 10 = {1}", n, n + 10);
        }
    }
}
