﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp程序设计实验.实验一
{
    class text_3
    {
        public text_3()
        {
            A a = new A();
            B b = new B();
            Console.WriteLine("请输入n:");
            int n = Int32.Parse(Console.ReadLine());
            Console.WriteLine("a.MyMethod(): ");
            a.MyMethod(n);
            Console.WriteLine("b.MyMethod(): ");
            b.MyMethod(n);
            Console.ReadLine();   
        }
    }
}
